<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>MedicApp - Medical & Hospital HTML5/Bootstrap admin template</title>
	<meta name="keywords" content="MedicApp">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="viewport" content="width=device-width,initial-scale=1"><!-- Favicon -->
	<link rel="shortcut icon" href="<?= base_url() ?>assets/img/favicon.ico"><!-- Plugins CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/icofont.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/simple-line-icons.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/jquery.typeahead.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/datatables.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/bootstrap-select.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/Chart.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/morris.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/leaflet.css"><!-- Theme CSS -->
	<!-- Select2 CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/select2/css/select2.min.css">

	<link rel="stylesheet" href="<?= base_url() ?>assets/css/styleMedic.css?version=4">
</head>
<body class="vertical-layout boxed">
<div class="app-loader main-loader">
	<div class="loader-box">
		<div class="bounceball"></div>
		<img src="<?= base_url() ?>assets/img/MediCareLogo.png" alt="logo">
	</div>
</div><!-- .main-loader -->
<div class="page-box">
	<div class="app-container"><!-- Horizontal navbar -->

		<?php
		include ("sidebar.php")
		?>

		<main class="main-content">
			<div class="app-loader"><i class="icofont-spinner-alt-4 rotate"></i></div>
			<div class="main-content-wrap">
				<header class="page-header"><h1 class="page-title float-left">Wallet</h1>
					<div style="border-left: 1px solid rgba(0,0,0,.1);">
						<div class="pl-5">
							<h5 class="mt-0">Total Balance</h5>
							<span class="link-icon icofont-rupee"></span> <?= $wallet->amount ?>
						</div>
					</div>
				</header>
				<div class="page-content">
					<hr>

					<form action="<?= base_url()?>wallet/paymentGateway" method="post">
						<input type="hidden" name="walletId" value="<?= $wallet->walletId ?>">
						<div class="row form-row mb-4" >
							<div class="col-md-6 ">
								<h5 class="ml-2">Add Money to Wallet</h5>
								<div class="form-inline ml-2">
									<input type="number" class="form-control" name="addAmount" id="txtAdd" >
									<input type="hidden" name="phar" value="1">
									<button type="submit" class="btn btn-primary ml-2" id="addMoney" name="type" value="0">Add Money</button>
								</div>
							</div>
							<div class="col-md-6">
								<h5>Withdraw Money from Wallet</h5>
								<div class="form-inline">
									<input type="number" class="form-control" name="withdrawAmount" id="txtWithdraw">
									<button type="submit" class="btn btn-primary ml-2" name="type" id="withdraw" value="1">Withdraw Money</button>
								</div>
							</div>
						</div>
					</form>
					<hr>
					<div class="row form-row ml-2" >
						<h5><b>Transactions</b></h5>
					</div>
					<div class="row form-row" >
						<div class="col">
							<table class="table table-bordered ">
								<tr>
									<th>Date</th>
									<th>Description</th>
									<th>Amount</th>
									<th>Status</th>
								</tr>
								<?php
								foreach ($tran as $t)
								{
									?>
									<tr>
										<td><?=date('d M y',strtotime($t['date']))?></td>
										<td><?= (($t['type'] == 1)? '<span class="link-icon icofont-upload"></span> &nbsp; ' : '<span class="link-icon icofont-download-alt"></span> &nbsp;&nbsp;').$t['desc'] ?></td>
										<td><?= (($t['type'] == 1)? '- ' : '+ ')?><i class="fas fa-rupee-sign"></i> <?= $t['amount']?></td>
										<td><?= ($t['status'] == 0)? 'Success' : 'Failed' ?></td>
									</tr>
									<?php
								}
								?>

							</table>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="app-footer">
			<div class="footer-wrap">
				<div class="row h-100 align-items-center">
					<div class="col-12 col-md-6 d-none d-md-block">
						<ul class="page-breadcrumbs">
							<li class="item"><a href="edit-account.html#" class="link">Apps</a> <i
									class="separator icofont-thin-right"></i></li>
							<li class="item"><a href="edit-account.html#" class="link">Service pages</a> <i
									class="separator icofont-thin-right"></i></li>
							<li class="item"><a href="edit-account.html#" class="link">Edit account</a> <i
									class="separator icofont-thin-right"></i></li>
						</ul>
					</div>
					<div class="col-12 col-md-6 text-right">
						<div class="d-flex align-items-center justify-content-center justify-content-md-end"><span>Version 1.0.0</span>
							<button class="no-style ml-2 settings-btn" data-toggle="modal" data-target="#settings"><span
									class="icon icofont-ui-settings text-primary"></span></button>
						</div>
					</div>
				</div>
				<div class="footer-skeleton">
					<div class="row align-items-center">
						<div class="col-12 col-md-6 d-none d-md-block">
							<ul class="page-breadcrumbs">
								<li class="item bg-1 animated-bg"></li>
								<li class="item bg animated-bg"></li>
							</ul>
						</div>
						<div class="col-12 col-md-6">
							<div class="info justify-content-center justify-content-md-end">
								<div class="version bg animated-bg"></div>
								<div class="settings animated-bg"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="content-overlay"></div>
	</div>
</div><!-- Add patients modals -->
<div class="modal fade" id="add-patient" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header"><h5 class="modal-title">Add new patient</h5></div>
			<div class="modal-body">
				<form>
					<div class="form-group avatar-box d-flex"><img src="<?= base_url() ?>assets/content/anonymous-400.jpg" width="40"
																   height="40" alt="" class="rounded-500 mr-4">
						<button class="btn btn-outline-primary" type="button">Select image<span
								class="btn-icon icofont-ui-user ml-2"></span></button>
					</div>
					<div class="form-group"><input class="form-control" type="text" placeholder="Name"></div>
					<div class="form-group"><input class="form-control" type="number" placeholder="Number"></div>
					<div class="row">
						<div class="col-12 col-sm-6">
							<div class="form-group"><input class="form-control" type="number" placeholder="Age"></div>
						</div>
						<div class="col-12 col-sm-6">
							<div class="form-group"><select class="selectpicker" title="Gender">
									<option class="d-none">Gender</option>
									<option>Male</option>
									<option>Female</option>
								</select></div>
						</div>
					</div>
					<div class="form-group mb-0"><textarea class="form-control" placeholder="Address"
														   rows="3"></textarea></div>
				</form>
			</div>
			<div class="modal-footer d-block">
				<div class="actions justify-content-between">
					<button type="button" class="btn btn-error" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-info">Add patient</button>
				</div>
			</div>
		</div>
	</div>
</div><!-- end Add patients modals --><!-- Add patients modals -->
<div class="modal fade" id="settings" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header"><h5 class="modal-title">Application's settings</h5></div>
			<div class="modal-body">
				<form>
					<div class="form-group"><label>Layout</label> <select class="selectpicker" title="Layout"
																		  id="layout">
							<option value="horizontal-layout">Horizontal</option>
							<option value="vertical-layout">Vertical</option>
						</select></div>
					<div class="form-group"><label>Light/dark topbar</label>
						<div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input"
																		 id="topbar"> <label
								class="custom-control-label" for="topbar"></label></div>
					</div>
					<div class="form-group"><label>Light/dark sidebar</label>
						<div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input"
																		 id="sidebar"> <label
								class="custom-control-label" for="sidebar"></label></div>
					</div>
					<div class="form-group mb-0"><label>Boxed/fullwidth mode</label>
						<div class="custom-control custom-switch"><input type="checkbox" class="custom-control-input"
																		 id="boxed" checked="checked"> <label
								class="custom-control-label" for="boxed"></label></div>
					</div>
				</form>
			</div>
			<div class="modal-footer d-block">
				<div class="actions justify-content-between">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
					<button id="reset-to-default" type="button" class="btn btn-error">Reset to default</button>
				</div>
			</div>
		</div>
	</div>
</div><!-- end Add patients modals -->
<script src="<?= base_url() ?>assets/js/jquery-3.3.1.min.js"></script>
<!--<script src="--><?//= base_url() ?><!--assets/js/jquery-migrate-1.4.1.min.js"></script>-->
<!--<script src="--><?//= base_url() ?><!--assets/js/popper.min.js"></script>-->
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.typeahead.min.js"></script>
<script src="<?= base_url() ?>assets/js/datatables.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap-select.min.js"></script>
<!--<script src="--><?//= base_url() ?><!--assets/js/jquery.barrating.min.js"></script>-->
<!--<script src="--><?//= base_url() ?><!--assets/js/Chart.min.js"></script>-->
<!--<script src="--><?//= base_url() ?><!--assets/js/raphael-min.js"></script>-->
<!--<script src="--><?//= base_url() ?><!--assets/js/morris.min.js"></script>-->
<!--<script src="--><?//= base_url() ?><!--assets/js/echarts.min.js"></script>-->
<!--<script src="--><?//= base_url() ?><!--assets/js/echarts-gl.min.js"></script>-->
<!-- Select2 JS -->
<script src="<?= base_url() ?>assets/plugins/select2/js/select2.min.js"></script>
<!-- parsley JS -->
<script src="<?= base_url() ?>assets/plugins/parsley/js/parsley.min.js"></script>

<script src="<?= base_url() ?>assets/js/main.js"></script>



<script>
</script>

<?php
include ("noti.php");
?>
</body>
</html>
