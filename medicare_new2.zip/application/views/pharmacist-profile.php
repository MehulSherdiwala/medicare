<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from dreamguys.co.in/demo/doccure/doctor-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jan 2020 18:14:59 GMT -->
<head>
	<meta charset="utf-8">
	<title>Doccure</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

	<!-- Favicons -->
	<link href="<?= base_url()?>assets/img/favicon.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url()?>assets/css/bootstrap.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="<?= base_url()?>assets/plugins/fontawesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="<?= base_url()?>assets/plugins/fontawesome/css/all.min.css">

	<!-- Fancybox CSS -->
	<link rel="stylesheet" href="<?= base_url()?>assets/plugins/fancybox/jquery.fancybox.min.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="<?= base_url()?>assets/css/style.css">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="<?= base_url()?>assets/js/html5shiv.min.js"></script>
	<script src="<?= base_url()?>assets/js/respond.min.js"></script>
	<![endif]-->

</head>
<body>

<!-- Main Wrapper -->
<div class="main-wrapper">

	<!-- Header -->
	<?php
	include ("header.php");
	?>
	<!-- /Header -->

	<!-- Breadcrumb -->
	<div class="breadcrumb-bar">
		<div class="container-fluid">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index.html">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Pharmacist Profile</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Pharmacist Profile</h2>
				</div>
			</div>
		</div>
	</div>
	<!-- /Breadcrumb -->

	<!-- Page Content -->
	<div class="content">
		<div class="container">

			<!-- Doctor Widget -->
			<div class="card">
				<div class="card-body">
					<div class="doctor-widget">
						<div class="doc-info-left">
							<div class="doctor-img">
								<img src="<?= base_url()?>assets/img/doctors/doctor-thumb-02.jpg" class="img-fluid" alt="User Image">
							</div>
							<div class="doc-info-cont">
								<h4 class="doc-name"><?= $pharData['username']?></h4>
								<p class="doc-speciality">Total <?= $totalMed?> types of Medicines</p>
								<div class="rating">
									<?php
									for ($i=1;$i<=5;$i++){
										if ($i <= $avgRate){
											echo "<i class='fas fa-star filled'></i>";
										} else {
											echo "<i class='fas fa-star'></i>";
										}
									}
									?>
									<span class="d-inline-block average-rating">(<?= $rating['count']?>)</span>
								</div>
								<div class="clinic-details">
									<p class="doc-location"><i class="fas fa-map-marker-alt"></i> <?= $stateCity['cityName']?>, <?= $stateCity['stateName']?></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- /Doctor Widget -->

			<!-- Doctor Details Tab -->
			<div class="card">
				<div class="card-body pt-0">

					<!-- Tab Menu -->
					<nav class="user-tabs mb-4">
						<ul class="nav nav-tabs nav-tabs-bottom nav-justified">
							<li class="nav-item">
								<a class="nav-link active" href="#doc_overview" data-toggle="tab">Overview</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="#doc_reviews" data-toggle="tab">Reviews</a>
							</li>
						</ul>
					</nav>
					<!-- /Tab Menu -->

					<!-- Tab Content -->
					<div class="tab-content pt-0">

						<!-- Overview Content -->
						<div role="tabpanel" id="doc_overview" class="tab-pane fade show active">
							<div class="row">
								<div class="col-md-12 col-lg-12">
									<!-- /About Details -->
									<?php
									if ($pharData['dptId'] == 3){
										?>
										<h4 class="text-center">Offline Pharmacist</h4>
										<hr>
										<?php
									}
									?>
									<!-- About Details -->
									<div class="widget about-widget">
										<h4 class="widget-title">About Me</h4>
										<p class="ml-3"><?= $pharData['description']?></p>
									</div>
									<!-- /About Details -->
									<hr>
									<!-- About Details -->
									<div class="widget about-widget">
										<h4 class="widget-title">Doctor Address</h4>
										<p class="ml-3"><i class="fas fa-map-marker-alt"></i> <?= $pharData['address']?></p>
									</div>
									<!-- /About Details -->

								</div>
							</div>
						</div>
						<!-- /Overview Content -->


						<!-- Reviews Content -->
						<div role="tabpanel" id="doc_reviews" class="tab-pane fade">

							<!-- Review Listing -->
							<div class="widget review-listing">
								<ul class="comments-list">

									<?php
									foreach ($rating['rate'] as $rate)
									{
										?>
										<li>
											<div class="comment">
												<img class="avatar avatar-sm rounded-circle" alt="User Image" src="<?= base_url()?>assets/img/patients/patient.jpg">
												<div class="comment-body w-100">
													<div class="meta-data">
														<span class="comment-author"><?= $rate['username']?></span>
														<span class="comment-date">Reviewed <?= $rate['datetime']?> ago</span>
														<div class="review-count rating">
															<?php
															for ($i=1;$i<=5;$i++){
																if ($i <= $rate['rates']){
																	echo "<i class='fas fa-star filled'></i>";
																} else {
																	echo "<i class='fas fa-star'></i>";
																}
															}
															?>

														</div>
													</div>
													<p class="comment-content">
														<?= $rate['description']?>
													</p>
												</div>
											</div>


										</li>
										<?php
									}
									?>

								</ul>

								<!-- Show All -->
								<div class="all-feedback text-center">
									<a href="#" class="btn btn-primary btn-sm">
										Show all feedback <strong>(<?= $rating['count']?>)</strong>
									</a>
								</div>
								<!-- /Show All -->

							</div>
							<!-- /Review Listing -->

							<?php
							if ($review == 1)
							{
								?>
								<!-- Write Review -->
								<div class="write-review">
									<h4>Write a review for <strong><?= $pharData['username']?></strong></h4>

									<!-- Write Review Form -->
									<form action="<?= base_url()?>viewProfile/pharmacistReview" method="post">
										<input type="hidden" name="pharId" value="<?= $pharData['pharId']?>">
										<input type="hidden" name="url" id="url">
										<div class="form-group">
											<label>Review</label>
											<div class="star-rating">
												<input id="star-5" type="radio" name="rating" value="5">
												<label for="star-5" title="5 stars">
													<i class="active fa fa-star"></i>
												</label>
												<input id="star-4" type="radio" name="rating" value="4">
												<label for="star-4" title="4 stars">
													<i class="active fa fa-star"></i>
												</label>
												<input id="star-3" type="radio" name="rating" value="3">
												<label for="star-3" title="3 stars">
													<i class="active fa fa-star"></i>
												</label>
												<input id="star-2" type="radio" name="rating" value="2">
												<label for="star-2" title="2 stars">
													<i class="active fa fa-star"></i>
												</label>
												<input id="star-1" type="radio" name="rating" value="1">
												<label for="star-1" title="1 star">
													<i class="active fa fa-star"></i>
												</label>
											</div>
										</div>
										<div class="form-group">
											<label>Your review</label>
											<textarea id="review_desc" maxlength="100" name="description"
													  class="form-control"></textarea>

											<div class="d-flex justify-content-between mt-3"><small
													class="text-muted"><span id="chars">100</span> characters
													remaining</small></div>
										</div>
										<hr>
										<div class="form-group">
											<div class="terms-accept">
												<div class="custom-checkbox">
													<input type="checkbox" id="terms_accept">
													<label for="terms_accept">I have read and accept <a href="#">Terms
															&amp; Conditions</a></label>
												</div>
											</div>
										</div>
										<div class="submit-section">
											<button type="submit" class="btn btn-primary submit-btn">Add Review
											</button>
										</div>
									</form>
									<!-- /Write Review Form -->

								</div>
								<!-- /Write Review -->
								<?php
							}
							?>

						</div>
						<!-- /Reviews Content -->
					</div>
				</div>
			</div>
			<!-- /Doctor Details Tab -->

		</div>
	</div>
	<!-- /Page Content -->

	<!-- Footer -->
	<footer class="footer">

		<!-- Footer Top -->
		<div class="footer-top">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-about">
							<div class="footer-logo">
								<img src="<?= base_url()?>assets/img/FooterMediCare.png" alt="logo">
							</div>
							<div class="footer-about-content">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
								<div class="social-icon">
									<ul>
										<li>
											<a href="#" target="_blank"><i class="fab fa-facebook-f"></i> </a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-twitter"></i> </a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-dribbble"></i> </a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- /Footer Widget -->

					</div>

					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-menu">
							<h2 class="footer-title">For Patients</h2>
							<ul>
								<li><a href="search.html"><i class="fas fa-angle-double-right"></i> Search for Doctors</a></li>
								<li><a href="login.html"><i class="fas fa-angle-double-right"></i> Login</a></li>
								<li><a href="register.html"><i class="fas fa-angle-double-right"></i> Register</a></li>
								<li><a href="booking.html"><i class="fas fa-angle-double-right"></i> Booking</a></li>
								<li><a href="patient-dashboard.html"><i class="fas fa-angle-double-right"></i> Patient Dashboard</a></li>
							</ul>
						</div>
						<!-- /Footer Widget -->

					</div>

					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-menu">
							<h2 class="footer-title">For Doctors</h2>
							<ul>
								<li><a href="appointments.html"><i class="fas fa-angle-double-right"></i> Appointments</a></li>
								<li><a href="chat.html"><i class="fas fa-angle-double-right"></i> Chat</a></li>
								<li><a href="login.html"><i class="fas fa-angle-double-right"></i> Login</a></li>
								<li><a href="doctor-register.html"><i class="fas fa-angle-double-right"></i> Register</a></li>
								<li><a href="doctor-dashboard.html"><i class="fas fa-angle-double-right"></i> Doctor Dashboard</a></li>
							</ul>
						</div>
						<!-- /Footer Widget -->

					</div>

					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-contact">
							<h2 class="footer-title">Contact Us</h2>
							<div class="footer-contact-info">
								<div class="footer-address">
									<span><i class="fas fa-map-marker-alt"></i></span>
									<p> 3556  Beech Street, San Francisco,<br> California, CA 94108 </p>
								</div>
								<p>
									<i class="fas fa-phone-alt"></i>
									+1 315 369 5943
								</p>
								<p class="mb-0">
									<i class="fas fa-envelope"></i>
									doccure@example.com
								</p>
							</div>
						</div>
						<!-- /Footer Widget -->

					</div>

				</div>
			</div>
		</div>
		<!-- /Footer Top -->

		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="container-fluid">

				<!-- Copyright -->
				<div class="copyright">
					<div class="row">
						<div class="col-md-6 col-lg-6">
							<div class="copyright-text">
								<p class="mb-0">&copy; 2019 Doccure. All rights reserved.</p>
							</div>
						</div>
						<div class="col-md-6 col-lg-6">

							<!-- Copyright Menu -->
							<div class="copyright-menu">
								<ul class="policy-menu">
									<li><a href="term-condition.html">Terms and Conditions</a></li>
									<li><a href="privacy-policy.html">Policy</a></li>
								</ul>
							</div>
							<!-- /Copyright Menu -->

						</div>
					</div>
				</div>
				<!-- /Copyright -->

			</div>
		</div>
		<!-- /Footer Bottom -->

	</footer>
	<!-- /Footer -->

</div>
<!-- /Main Wrapper -->

<!-- Voice Call Modal -->
<div class="modal fade call-modal" id="voice_call">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-body">
				<!-- Outgoing Call -->
				<div class="call-box incoming-box">
					<div class="call-wrapper">
						<div class="call-inner">
							<div class="call-user">
								<img alt="User Image" src="<?= base_url()?>assets/img/doctors/doctor-thumb-02.jpg" class="call-avatar">
								<h4>Dr. Darren Elder</h4>
								<span>Connecting...</span>
							</div>
							<div class="call-items">
								<a href="javascript:void(0);" class="btn call-item call-end" data-dismiss="modal" aria-label="Close"><i class="material-icons">call_end</i></a>
								<a href="voice-call.html" class="btn call-item call-start"><i class="material-icons">call</i></a>
							</div>
						</div>
					</div>
				</div>
				<!-- Outgoing Call -->

			</div>
		</div>
	</div>
</div>
<!-- /Voice Call Modal -->

<!-- Video Call Modal -->
<div class="modal fade call-modal" id="video_call">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-body">

				<!-- Incoming Call -->
				<div class="call-box incoming-box">
					<div class="call-wrapper">
						<div class="call-inner">
							<div class="call-user">
								<img class="call-avatar" src="<?= base_url()?>assets/img/doctors/doctor-thumb-02.jpg" alt="User Image">
								<h4>Dr. Darren Elder</h4>
								<span>Calling ...</span>
							</div>
							<div class="call-items">
								<a href="javascript:void(0);" class="btn call-item call-end" data-dismiss="modal" aria-label="Close"><i class="material-icons">call_end</i></a>
								<a href="video-call.html" class="btn call-item call-start"><i class="material-icons">videocam</i></a>
							</div>
						</div>
					</div>
				</div>
				<!-- /Incoming Call -->

			</div>
		</div>
	</div>
</div>
<!-- Video Call Modal -->

<!-- jQuery -->
<script src="<?= base_url()?>assets/js/jquery.min.js"></script>

<!-- Bootstrap Core JS -->
<script src="<?= base_url()?>assets/js/popper.min.js"></script>
<script src="<?= base_url()?>assets/js/bootstrap.min.js"></script>

<!-- Fancybox JS -->
<script src="<?= base_url()?>assets/plugins/fancybox/jquery.fancybox.min.js"></script>

<!-- Custom JS -->
<script src="<?= base_url()?>assets/js/script.js"></script>

<script>
	$(document).ready(function () {
		$("#url").val(window.location.href);
	});
</script>
</body>

<!-- Mirrored from dreamguys.co.in/demo/doccure/doctor-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jan 2020 18:14:59 GMT -->
</html>
