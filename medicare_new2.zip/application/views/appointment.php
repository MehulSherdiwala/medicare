<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Doccure</title>

	<!-- Favicons -->
	<link type="image/x-icon" href="<?= base_url() ?>assets/img/favicon.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/bootstrap.min.css">

	<!-- Select2 CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/select2/css/select2.min.css">
	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/fontawesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/fontawesome/css/all.min.css">

	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/datepicker/css/bootstrap-datepicker.min.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css?version=11">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
		<script src="<?= base_url() ?>assets/js/html5shiv.min.js"></script>
		<script src="<?= base_url() ?>assets/js/respond.min.js"></script>
	<![endif]-->


</head>
<body>
<div hidden id="spinner"></div>

<!-- Main Wrapper -->
<div class="main-wrapper">

	<!-- Header -->
	<?php
	include("header.php");
	?>
	<!-- /Header -->

	<div class="breadcrumb-bar">
		<div class="container-fluid">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Appointment</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Book Appointment</h2>
				</div>
			</div>
		</div>
	</div>

	<div class="content" style="min-height: 205px;">
		<div class="container-fluid">
			<div class="row">
				<div class="col col-md-10 offset-1">
					<div class="card">
						<div class="card-body">
							<h2 class=" text-center">Appointment</h2>
							<!--data-parsley-validate-->
							<form action="<?= base_url() ?>appointment/pay" method="post"   id="form">
								<div class="col-md-6 offset-3 ">
									<div class="form-group">
										<label>Appointment Type</label>
										<select name="appType" id="appType" class="select2 form-control">
											<option value="2">Select</option>
											<option value="0">Clinic Appointment</option>
											<option value="1">Instant Cure Appointment</option>
										</select>
									</div>
								</div>
								<div class="col-md-4 mt-3 offset-4 text-center d-none" id="ICpriceSec">
									<div class="form-group">
										<label>Consulting Fees : </label>
										<span class="badge" style="font-size: 14px;"><i
												class="fas fa-rupee-sign"></i> 300</span>
										<input type="hidden" name="icprice" class="price" value="300" >
									</div>
								</div>
								<div id="sec" class="d-none">
									<div class="row">
										<div class="col-md-6 offset-3 mt-3 text-center" id="typeSec">
											<div class="form-group form-focus mb-0">
												<div class="custom-control custom-radio custom-control-inline">
													<input type="radio" id="doctor" name="type"
														   class="custom-control-input" value="0" >
													<label class="custom-control-label" for="doctor">Doctor</label>
												</div> &nbsp;&nbsp;
												<div class="custom-control custom-radio custom-control-inline">
													<input type="radio" id="clinic" name="type" value="1"
														   class="custom-control-input" checked>
													<label class="custom-control-label" for="clinic">Clinic</label>
												</div>
											</div>
										</div>
										<div class="col-md-6 offset-3" id="dropdwnSec">
											<select id="dropdwn" name="id" class="select2 form-control" style="width: 100%">
												<option value="">Select</option>
											</select>
										</div>
										<div class="col-md-8 mt-3 offset-2">
											<div id="schedule"></div>
										</div>
										<div class="col-md-8 mt-3 offset-2 d-none" id="dateSec">
											<div class="form-group">
												<label>Select Date</label>
												<input class="form-control" type="text" placeholder="Date" name="date"
													   id="date"  autocomplete="off">
											</div>
										</div>
										<div class="col-md-8 mt-3 offset-2 d-none" id="timeSec">
											<div class="form-group">
												<label>Select Time Slot</label>
												<select id="timeSlot" class="select2 form-control" name="timeSlot"
														 data-parsley-min="1"
														data-parsley-min-message="This value is required.">
													<option value="">Select</option>
												</select>
											</div>
										</div>
										<div class="col-md-8 mt-3 offset-2 d-none" id="checkSec">
											<div class="form-group">
												<button type="button" class="btn btn-info" id="check">Check
													Availability
												</button>
												<span class="float-right badge" id="appTime"
													  style="font-size: 16px;line-height: 25px;display: block;height: 38px;"></span>
											</div>
										</div>
										<div class="col-md-8 mt-3 offset-2 d-none" id="descSec">
											<div class="form-group">
												<label>Description</label>
												<input class="form-control" type="text" placeholder="Description"
													   name="desc" id="desc" >
											</div>
										</div>
										<div class="col-md-4 mt-3 offset-4 text-center d-none" id="priceSec">
											<div class="form-group">
												<label>Consulting Fees : </label>
												<span class="badge" style="font-size: 14px;"><i
														class="fas fa-rupee-sign"></i> <span id="price"></span></span>
												<input type="hidden" name="price" class="price">
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-4 mt-3 offset-4 text-center">
									<div class="form-group">
										<button type="submit" id="submit" class="btn btn-success">Proceed To Pay</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

	<!-- Footer -->
	<footer class="footer">

		<!-- Footer Top -->
		<div class="footer-top">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-about">
							<div class="footer-logo">
								<img src="<?= base_url() ?>assets/img/FooterMediCare.png" alt="logo">
							</div>
							<div class="footer-about-content">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
								<div class="social-icon">
									<ul>
										<li>
											<a href="#" target="_blank"><i class="fab fa-facebook-f"></i> </a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-twitter"></i> </a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fab fa-dribbble"></i> </a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- /Footer Widget -->

					</div>

					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-menu">
							<h2 class="footer-title">For Patients</h2>
							<ul>
								<li><a href="search.html"><i class="fas fa-angle-double-right"></i> Search for Doctors</a></li>
								<li><a href="login.php"><i class="fas fa-angle-double-right"></i> Login</a></li>
								<li><a href="register.php"><i class="fas fa-angle-double-right"></i> Register</a></li>
								<li><a href="booking.html"><i class="fas fa-angle-double-right"></i> Booking</a></li>
								<li><a href="patient-dashboard.html"><i class="fas fa-angle-double-right"></i> Patient Dashboard</a></li>
							</ul>
						</div>
						<!-- /Footer Widget -->

					</div>

					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-menu">
							<h2 class="footer-title">For Doctors</h2>
							<ul>
								<li><a href="appointments.html"><i class="fas fa-angle-double-right"></i> Appointments</a></li>
								<li><a href="chat.html"><i class="fas fa-angle-double-right"></i> Chat</a></li>
								<li><a href="login.php"><i class="fas fa-angle-double-right"></i> Login</a></li>
								<li><a href="doctor-register.html"><i class="fas fa-angle-double-right"></i> Register</a></li>
								<li><a href="doctor-dashboard.html"><i class="fas fa-angle-double-right"></i> Doctor Dashboard</a></li>
							</ul>
						</div>
						<!-- /Footer Widget -->

					</div>

					<div class="col-lg-3 col-md-6">

						<!-- Footer Widget -->
						<div class="footer-widget footer-contact">
							<h2 class="footer-title">Contact Us</h2>
							<div class="footer-contact-info">
								<div class="footer-address">
									<span><i class="fas fa-map-marker-alt"></i></span>
									<p> 3556  Beech Street, San Francisco,<br> California, CA 94108 </p>
								</div>
								<p>
									<i class="fas fa-phone-alt"></i>
									+1 315 369 5943
								</p>
								<p class="mb-0">
									<i class="fas fa-envelope"></i>
									doccure@example.com
								</p>
							</div>
						</div>
						<!-- /Footer Widget -->

					</div>

				</div>
			</div>
		</div>
		<!-- /Footer Top -->

		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="container-fluid">

				<!-- Copyright -->
				<div class="copyright">
					<div class="row">
						<div class="col-md-6 col-lg-6">
							<div class="copyright-text">
								<p class="mb-0">&copy; 2019 Doccure. All rights reserved.</p>
							</div>
						</div>
						<div class="col-md-6 col-lg-6">

							<!-- Copyright Menu -->
							<div class="copyright-menu">
								<ul class="policy-menu">
									<li><a href="term-condition.html">Terms and Conditions</a></li>
									<li><a href="privacy-policy.html">Policy</a></li>
								</ul>
							</div>
							<!-- /Copyright Menu -->

						</div>
					</div>
				</div>
				<!-- /Copyright -->

			</div>
		</div>
		<!-- /Footer Bottom -->

	</footer>
	<!-- /Footer -->

</div>
<!-- /Main Wrapper -->

<!-- jQuery -->
<script src="<?= base_url() ?>assets/js/jquery.min.js"></script>

<!-- Bootstrap Core JS -->
<script src="<?= base_url() ?>assets/js/popper.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
<!-- Select2 JS -->
<script src="<?= base_url() ?>assets/plugins/select2/js/select2.min.js"></script>

<script src="<?= base_url() ?>assets/plugins/datepicker/js/bootstrap-datepicker.min.js"></script>

<!-- parsley JS -->
<script src="<?= base_url() ?>assets/plugins/parsley/js/parsley.min.js"></script>

<!-- Slick JS -->
<!--<script src="--><?//= base_url() ?><!--assets/js/slick.js"></script>-->

<!-- Custom JS -->
<script src="<?= base_url() ?>assets/js/script.js"></script>

<script>
	$(document).ready(function () {
		$(".select2").select2();
		$("#date").datepicker({
			startDate: new Date(),
			autoclose: true,
			format:  "dd-mm-yyyy"
		});
		const spinner = $("#spinner");


		$("#appType").on('change', function () {
			let value = $(this).val();
			if (value == 0) {
				$("#sec").removeClass('d-none');
				$("#ICpriceSec").addClass('d-none');
				$("#dropdwn,#date,#timeSlot,#desc").prop('required',true);
			}else if(value == 1) {
				$("#sec").addClass('d-none');
				$("#ICpriceSec").removeClass('d-none');
				$("#dropdwn,#date,#timeSlot,#desc").prop('required',false);
				$("#form").parsley();
			} else {
				$("#sec").addClass('d-none');
				$("#ICpriceSec").addClass('d-none');
				$("#dropdwn,#date,#timeSlot,#desc").prop('required',true);
			}
		});

		$("input[name='type']").on('change', function () {
			const type = $(this).val();
			fetchType(type);
		});
		fetchType(1);

		async function fetchType(type){
			spinner.removeAttr('hidden');
			const response = await fetch('<?= base_url()?>appointment/fetchType/' + type);
			const myJson = await response.json();
			$('#dropdwn')
				.empty()
				.append($("<option></option>")
					.text("Select"));
			$.each(myJson , function (key , value) {
				$('#dropdwn')
					.append($("<option></option>")
						.attr("value" , value.id)
						.text(value.name));
			});
			spinner.attr('hidden', '');

		}
		$("#dropdwn").on('change', function () {
			const id = $(this).val();
			if (id !== 'Select'){
				fetchSchedule(id);
				$("#dateSec,#priceSec,#descSec").removeClass("d-none");
			}
		});
		async function fetchSchedule(id){
			const type = $("input[name='type']").val();
			spinner.removeAttr('hidden');
			const response = await fetch('<?= base_url()?>appointment/fetchSchedule/' + type + '/' + id);
			const myJson = await response.json();

			let html = '';
			html += '<table class="table table-bordered" id="data-table" style="background: #ffffff">\n' +
				'<thead>\n' +
				'<tr>\n' +
				'<th scope="col">Day</th>\n' +
				'<th scope="col">Timing </th>\n' +
				'</tr>\n' +
				'</thead>\n' +
				'<tbody>';
			for (let i = 0; i < myJson.length; i++) {

				html += '<tr>\n' +
					'<td>'+ myJson[i].day +'</td>\n' +
					'<td>'+ myJson[i].time +'</td>\n' +
					'</tr>';
			}
			html += '</tbody></table>';
			$("#schedule").html(html);

			$("#price").text(myJson[0].price);
			$(".price").val(myJson[0].price);

			spinner.attr('hidden', '');

		}

		$("#date").on('change', function () {
			const date = $(this).val();
			const id = $("#dropdwn").val();
			const type = $("input[name='type']").val();
			$("#timeSec").removeClass("d-none");

			$.ajax({
				url: '<?= base_url()?>appointment/fetchTimeSlot',
				method:'post',
				data:{
					date:date,
					id:id,
					type:type
				},
				beforeSend: function () {
					spinner.removeAttr('hidden');
				},
				success:function (data) {
					let obj = JSON.parse(data);
					$('#timeSlot')
						.empty()
						.append($("<option></option>")
							.text("Select"));
					$.each(obj , function (key , value) {
						$('#timeSlot')
							.append($("<option></option>")
								.attr("value" , value.acId)
								.text(value.time));
					});
					$(".select2").select2();
				},
				complete: function () {
					spinner.attr('hidden', '');
				}
			})
		});
		$('#timeSlot').on('change', function () {
			$("#checkSec").removeClass("d-none");
			availability();
		});

		$("#check").on('click', function () {
			const date = $("#date").val();
			const id = $("#dropdwn").val();
			const timeSlot = $("#timeSlot").val();
			const type = $("input[name='type']").val();

			$.ajax({
				url: '<?= base_url() ?>appointment/checkAvailability',
				method:'post',
				data:{
					date:date,
					id:id,
					type:type,
					timeSlot:timeSlot,
				},
				success:function (data) {
					if (data == 0){
						alert('Appointment is not Available.');
						$("#appTime").text('');
						$("#availability").val(0);
					} else {
						alert('Appointment is Available.');
						$("#appTime").text(data);
						$("#availability").val(0);
					}
				}
			})
		});


		async function availability() {
			const date = $("#date").val();
			const id = $("#dropdwn").val();
			const timeSlot = $("#timeSlot").val();
			const type = $("input[name='type']").val();
			let res = false;

			await $.ajax({
				url: '<?= base_url() ?>appointment/checkAvailability',
				method:'post',
				data:{
					date:date,
					id:id,
					type:type,
					timeSlot:timeSlot,
				},
				success:function (data) {
					if (data == 0){
						$("#submit").attr('disabled',true);
					} else {
						$("#submit").attr('disabled',false);
					}
				}
			});
			return res;
		}

	});
</script>

<script>

	checkApp();
	async function checkApp() {
		const res = await fetch('<?= base_url()?>appointment/checkIC');
		const data = await res.json();

		if (data > 0){
			$(".instant-cure").removeClass("d-none");
			$(".instant-cure a").attr('href', '<?= base_url()?>chat/'+ data);
		}
	}
</script>

</body>

</html>
