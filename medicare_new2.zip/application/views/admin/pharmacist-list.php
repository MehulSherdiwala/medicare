<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>MedicApp - Medical & Hospital HTML5/Bootstrap admin template</title>
	<meta content="MedicApp" name="keywords">
	<meta content="" name="description">
	<meta content="" name="author">
	<meta content="width=device-width,initial-scale=1" name="viewport">
	<!-- Favicon -->
	<link href="<?= base_url() ?>assets/img/favicon.ico" rel="shortcut icon">
	<!-- Plugins CSS -->
	<link href="<?= base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/icofont.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/simple-line-icons.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/jquery.typeahead.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/datatables.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/Chart.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/morris.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/leaflet.css" rel="stylesheet">
	<!-- Theme CSS -->
	<link href="<?= base_url() ?>assets/css/styleMedic.css?version=5" rel="stylesheet">
	<style>
		span.form-control{
			min-height: 40px!important;
		}
	</style>
</head>
<body class="vertical-layout boxed">
<div class="app-loader main-loader">
	<div class="loader-box">
		<div class="bounceball"></div>
		<img src="<?= base_url() ?>assets/img/MediCareLogo.png" alt="logo">
	</div>
</div>
<!-- .main-loader -->
<div class="page-box">
	<div class="app-container"><!-- Horizontal navbar -->

		<?php
		include "sidebar.php"
		?>

		<main class="main-content">
			<div class="app-loader"><i class="icofont-spinner-alt-4 rotate"></i></div>
			<div class="main-content-wrap">
				<header class="page-header"><h1 class="page-title">Pharmacist</h1></header>
				<div class="page-content">
					<div class="card mb-0">
						<div class="card-body">
							<div class="table-responsive" id="data">

							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="app-footer">
			<div class="footer-wrap">
				<div class="row h-100 align-items-center">
					<div class="col-12 col-md-6 d-none d-md-block">
						<ul class="page-breadcrumbs">
							<li class="item"><a class="link" href="appointments.html#">Medicine</a> <i
									class="separator icofont-thin-right"></i></li>
							<li class="item"><a class="link" href="appointments.html#">Appointments</a> <i
									class="separator icofont-thin-right"></i></li>
						</ul>
					</div>
					<div class="col-12 col-md-6 text-right">
						<div class="d-flex align-items-center justify-content-center justify-content-md-end"><span>Version 1.0.0</span>
							<button class="no-style ml-2 settings-btn" data-target="#settings" data-toggle="modal"><span
									class="icon icofont-ui-settings text-primary"></span></button>
						</div>
					</div>
				</div>
				<div class="footer-skeleton">
					<div class="row align-items-center">
						<div class="col-12 col-md-6 d-none d-md-block">
							<ul class="page-breadcrumbs">
								<li class="item bg-1 animated-bg"></li>
								<li class="item bg animated-bg"></li>
							</ul>
						</div>
						<div class="col-12 col-md-6">
							<div class="info justify-content-center justify-content-md-end">
								<div class="version bg animated-bg"></div>
								<div class="settings animated-bg"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="content-overlay"></div>
	</div>
</div>
<!-- Add patients modals -->
<div aria-hidden="true" class="modal fade" id="add-patient" role="dialog" tabindex="-1">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header"><h5 class="modal-title">Add new patient</h5></div>
			<div class="modal-body">
				<form>
					<div class="form-group avatar-box d-flex"><img alt="" class="rounded-500 mr-4"
																   height="40" src="<?= base_url() ?>assets/content/anonymous-400.jpg" width="40">
						<button class="btn btn-outline-primary" type="button">Select image<span
								class="btn-icon icofont-ui-user ml-2"></span></button>
					</div>
					<div class="form-group"><input class="form-control" placeholder="Name" type="text"></div>
					<div class="form-group"><input class="form-control" placeholder="Number" type="number"></div>
					<div class="row">
						<div class="col-12 col-sm-6">
							<div class="form-group"><input class="form-control" placeholder="Age" type="number"></div>
						</div>
						<div class="col-12 col-sm-6">
							<div class="form-group"><select class="selectpicker" title="Gender">
									<option class="d-none">Gender</option>
									<option>Male</option>
									<option>Female</option>
								</select></div>
						</div>
					</div>
					<div class="form-group mb-0"><textarea class="form-control" placeholder="Address"
														   rows="3"></textarea></div>
				</form>
			</div>
			<div class="modal-footer d-block">
				<div class="actions justify-content-between">
					<button class="btn btn-error" data-dismiss="modal" type="button">Cancel</button>
					<button class="btn btn-info" type="button">Add patient</button>
				</div>
			</div>
		</div>
	</div>
</div><!-- end Add patients modals --><!-- Add patients modals -->
<div aria-hidden="true" class="modal fade" id="settings" role="dialog" tabindex="-1">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header"><h5 class="modal-title">Application's settings</h5></div>
			<div class="modal-body">
				<form>
					<div class="form-group"><label>Layout</label> <select class="selectpicker" id="layout"
																		  title="Layout">
							<option value="horizontal-layout">Horizontal</option>
							<option value="vertical-layout">Vertical</option>
						</select></div>
					<div class="form-group"><label>Light/dark topbar</label>
						<div class="custom-control custom-switch"><input class="custom-control-input" id="topbar"
																		 type="checkbox"> <label
								class="custom-control-label" for="topbar"></label></div>
					</div>
					<div class="form-group"><label>Light/dark sidebar</label>
						<div class="custom-control custom-switch"><input class="custom-control-input" id="sidebar"
																		 type="checkbox"> <label
								class="custom-control-label" for="sidebar"></label></div>
					</div>
					<div class="form-group mb-0"><label>Boxed/fullwidth mode</label>
						<div class="custom-control custom-switch"><input checked="checked" class="custom-control-input"
																		 id="boxed" type="checkbox"> <label
								class="custom-control-label" for="boxed"></label></div>
					</div>
				</form>
			</div>
			<div class="modal-footer d-block">
				<div class="actions justify-content-between">
					<button class="btn btn-secondary" data-dismiss="modal" type="button">Cancel</button>
					<button class="btn btn-error" id="reset-to-default" type="button">Reset to default</button>
				</div>
			</div>
		</div>
	</div>
</div><!-- end Add patients modals --><!-- Add appointment modals -->
<div aria-hidden="true" class="modal fade" id="view-doctor" role="dialog" tabindex="-1">
	<div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header"><h5 class="modal-title">Pharmacist Details</h5></div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="">Pharmacist Id</label>
							<span class="form-control" id="docId"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="">Name</label>
							<span class="form-control" id="name"></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="">Email ID</label>
							<span class="form-control" id="email"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="">Joining Date</label>
							<span class="form-control" id="joindate"></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="">Pharmacist Type</label>
							<span class="form-control" id="dpType"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="">Pincode</label>
							<span class="form-control" id="pincode"></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="">Address</label>
							<span class="form-control" id="address"></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="">State</label>
							<span class="form-control" id="state"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="">City</label>
							<span class="form-control" id="city"></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="">Description</label>
							<span class="form-control" id="description"></span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6 offset-3">
						<div class="form-group">
							<label for="">status</label>
							<span class="form-control" id="status"></span>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer d-block">
				<div class="actions justify-content-between">
					<button class="btn btn-error" data-dismiss="modal" type="button">Close</button>
				</div>
			</div>
		</div>
	</div>
</div><!-- end Add appointment modals -->
<div aria-hidden="true" class="modal fade" id="edit-doctor" role="dialog" tabindex="-1">
	<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header"><h5 class="modal-title">Edit Pharmacist</h5></div>
			<div class="modal-body">
				<div class="form-group">
					<label for="">Pharmacist Id</label>
					<span class="form-control" id="editdocId"></span>
				</div>
				<div class="form-group">
					<label for="">Pharmacist Name</label>
					<span class="form-control" id="editname"></span>
				</div>
				<div class="form-group">
					<label for="">Pharmacist Status</label>
					<select id="docStatus" class="selectpicker">
						<option value="">Select</option>
						<option value="0">Not Verified</option>
						<option value="1">Verified</option>
						<option value="2">Preferred</option>
					</select>
				</div>
			</div>
			<div class="modal-footer d-block">
				<div class="actions justify-content-between">
					<button class="btn btn-error" data-dismiss="modal" type="button">Cancel</button>
					<button class="btn btn-info" data-dismiss="modal" type="button" id="editDoc">Update</button>
				</div>
			</div>
		</div>
	</div>
</div><!-- end Add appointment modals -->
<script src="<?= base_url() ?>assets/js/jquery-3.3.1.min.js"></script>
<!--<script src="<?= base_url() ?>assets/js/jquery-migrate-1.4.1.min.js"></script>-->
<script src="<?= base_url() ?>assets/js/popper.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.typeahead.min.js"></script>
<script src="<?= base_url() ?>assets/js/datatables.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap-select.min.js"></script>
<!-- parsley JS -->
<script src="<?= base_url() ?>assets/plugins/parsley/js/parsley.min.js"></script>
<!--<script src="<?= base_url() ?>assets/js/jquery.barrating.min.js"></script>-->
<!--<script src="<?= base_url() ?>assets/js/Chart.min.js"></script>-->
<!--<script src="<?= base_url() ?>assets/js/raphael-min.js"></script>-->
<!--<script src="<?= base_url() ?>assets/js/morris.min.js"></script>-->
<!--<script src="<?= base_url() ?>assets/js/echarts.min.js"></script>-->
<!--<script src="<?= base_url() ?>assets/js/echarts-gl.min.js"></script>-->
<script src="<?= base_url() ?>assets/js/main.js"></script>

<script>
	fetchDoctor();
	async function fetchDoctor() {
		const response = await fetch('<?= base_url()?>admin/Pharmacist/fetchPharmacistList');
		const myJson = await response.json();
		let html = '';
		html += '<table class="table" id="data-table">\n' +
			'<thead>\n' +
			'<tr>\n' +
			'<th scope="col">Pharmacist Id</th>\n' +
			'<th scope="col">Pharmacist Name</th>\n' +
			'<th scope="col">Email</th>\n' +
			'<th scope="col">Address</th>\n' +
			'<th scope="col">JoinDate</th>\n' +
			'<th scope="col">Total Medicine</th>\n' +
			'<th scope="col">Profile</th>\n' +
			'<th scope="col">Status</th>\n' +
			'<th scope="col"></th>\n' +
			'</tr>\n' +
			'</thead>\n' +
			'<tbody>';
		for (let i = 0; i < myJson.length; i++) {

			html += '<tr>\n' +
				'<td>'+ myJson[i].pharId+'</td>\n' +
				'<td>'+ myJson[i].username+'</td>\n' +
				'<td>'+ myJson[i].email+'</td>\n' +
				'<td>'+ myJson[i].address+'</td>\n' +
				'<td>'+ myJson[i].joindate+'</td>\n' +
				'<td>'+ myJson[i].totalMed+'</td>\n' +
				'<td>'+ ((myJson[i].profile == 0) ? '<span class="badge badge-success">Completed</span>' : '<span class="badge badge-danger">Pending</span>' ) +'</td>\n' +
				'<td>'+ ((myJson[i].status == 0) ? '<span class="badge badge-danger">Not Verified</span>' : ((myJson[i].status == 1) ? '<span class="badge badge-success">Verified</span>' : '<span class="badge badge-warning">Preferred</span>' ) )+'</td>\n' +
				'<td>\n' +
				'<div class="actions">\n' +
				'<button class="btn btn-info btn-sm btn-square rounded-pill edit-doctor" data-pharid="'+ myJson[i].pharId+'" data-target="#edit-doctor" data-toggle="modal"><span\n' +
				'class="btn-icon icofont-ui-edit"></span></button>\n' +
				'<button class="btn btn-success btn-sm btn-square rounded-pill view-doctor" data-pharid="'+ myJson[i].pharId+'" data-target="#view-doctor" data-toggle="modal"><span\n' +
				'class="btn-icon icofont-eye-alt"></span></button>\n' +
				'</div>\n' +
				'</td>\n' +
				'</tr>';
		}
		html += '</tbody></table>';
		$("#data").html(html);
		$("#data-table").DataTable();

		$(".view-doctor").on('click',function () {
			const pharId = $(this).data("pharid");
			console.log((pharId));
			viewDoc(pharId);
		});

		$(".edit-doctor").on('click',function () {
			const pharId = $(this).data("pharid");
			// const docStatus = $("#docStatus").val();
			fetchDoc(pharId);
		});
	}

	async function fetchDoc(id) {
		const response = await fetch('<?= base_url()?>admin/pharmacist/fetchPhar/'+ id);
		const myJson = await response.json();

		console.log(myJson);
		$("#editdocId").text(myJson.pharId);
		$("#editname").text(myJson.username);
		$("#docStatus>option[value=" + myJson.status + "]").prop("selected" , true);

		$('.selectpicker').selectpicker('refresh');

	}

	$(".view-doctor").on('click',function () {
		const docId = $(this).data("pharid");
		// console.log((docId));
		viewDoc(docId);
	});

	async function viewDoc(id) {
		const response = await fetch('<?= base_url()?>admin/Pharmacist/pharmacistDetail/' + id);
		const myJson = await response.json();
		// console.log(myJson);

		$("#docId").text(myJson.pharId);
		$("#name").text(myJson.username);
		$("#email").text(myJson.email);
		$("#dpType").text(myJson.dpType);
		$("#pincode").text(myJson.pincode);
		$("#address").text(myJson.address);
		$("#state").text(myJson.stateName);
		$("#city").text(myJson.cityName);
		$("#description").text(myJson.description);
		$("#joindate").text(myJson.joindate);
		$("#status").text(myJson.status);

	}

	$("#editDoc").on('click', function () {
		const pharId = $("#editdocId").text();
		const pharStatus = $("#docStatus").val();

		$.ajax({
			url: '<?= base_url()?>admin/pharmacist/updateStatus' ,
			method: 'post',
			data: {
				pharId:pharId,
				pharStatus:pharStatus,
			},
			success:function (data) {
				fetchDoctor();
			}
		})

	})
</script>
</body>
</html>
