<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>MedicApp - Medical & Hospital HTML5/Bootstrap admin template</title>
    <meta content="MedicApp" name="keywords">
    <meta content="" name="description">
    <meta content="" name="author">
    <meta content="width=device-width,initial-scale=1" name="viewport"><!-- Favicon -->
    <link href="<?= base_url() ?>assets/img/favicon.ico" rel="shortcut icon"><!-- Plugins CSS -->
    <link href="<?= base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/icofont.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/simple-line-icons.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/jquery.typeahead.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/datatables.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/Chart.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/morris.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/leaflet.css" rel="stylesheet"><!-- Theme CSS -->
    <link href="<?= base_url() ?>assets/css/styleMedic.css" rel="stylesheet">
</head>
<body class="vertical-layout boxed">
<div class="app-loader main-loader">
    <div class="loader-box">
        <div class="bounceball"></div>
        <img src="<?= base_url() ?>assets/img/MediCareLogo.png" alt="logo">
    </div>
</div><!-- .main-loader -->
<div class="page-box">
    <div class="app-container">
		<!-- navbar -->
		<?php
			include "sidebar.php";
		?>
		<!-- end navbar -->
        <main class="main-content">
            <div class="app-loader"><i class="icofont-spinner-alt-4 rotate"></i></div>
            <div class="main-content-wrap">
                <div class="page-content">
                    <div class="row">
                        <div class="col col-12 col-md-6 col-xl-3">
                            <div class="card animated fadeInUp delay-01s bg-light">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col col-5">
                                            <div class="icon p-0 fs-48 text-primary opacity-50 icofont-first-aid-alt"></div>
                                        </div>
                                        <div class="col col-7"><h6 class="mt-0 mb-1">Appointments</h6>
                                            <div class="count text-primary fs-20">213</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12 col-md-6 col-xl-3">
                            <div class="card animated fadeInUp delay-02s bg-light">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col col-5">
                                            <div class="icon p-0 fs-48 text-primary opacity-50 icofont-wheelchair"></div>
                                        </div>
                                        <div class="col col-7"><h6 class="mt-0 mb-1">New patients</h6>
                                            <div class="count text-primary fs-20">104</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12 col-md-6 col-xl-3">
                            <div class="card animated fadeInUp delay-03s bg-light">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col col-5">
                                            <div class="icon p-0 fs-48 text-primary opacity-50 icofont-blood"></div>
                                        </div>
                                        <div class="col col-7"><h6 class="mt-0 mb-1">Operations</h6>
                                            <div class="count text-primary fs-20">24</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12 col-md-6 col-xl-3">
                            <div class="card animated fadeInUp delay-04s bg-light">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col col-5">
                                            <div class="icon p-0 fs-48 text-primary opacity-50 icofont-dollar-true"></div>
                                        </div>
                                        <div class="col col-7"><h6 class="mt-0 mb-1 text-nowrap">Hospital Earning</h6>
                                            <div class="count text-primary fs-20">$5238</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">Hospital survey</div>
                        <div class="card-body">
                            <div class="chat-container container-h-400" id="surveyEcharts"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col col-12 col-md-6">
                            <div class="card">
                                <div class="card-body"><h4 class="mt-0 mb-1">$25038</h4>
                                    <p class="text-muted mb-0">Income in current month</p>
                                    <div class="chat-container" id="incomeEcharts"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12 col-md-6">
                            <div class="card">
                                <div class="card-body"><h4 class="mt-0 mb-1">$2195</h4>
                                    <p class="text-muted mb-0">Income in current week</p>
                                    <div class="chat-container" id="income2Echarts"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12 col-md-4">
                            <div class="card">
                                <div class="card-header">Patients age</div>
                                <div class="card-body">
                                    <div class="chat-container container-h-300" id="ageEcharts"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12 col-md-4">
                            <div class="card">
                                <div class="card-header">Patients gender</div>
                                <div class="card-body">
                                    <div class="chat-container container-h-300" id="genderEcharts"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-12 col-md-4">
                            <div class="card">
                                <div class="card-header">Departments</div>
                                <div class="card-body">
                                    <div class="chat-container container-h-300" id="departmentsEcharts"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-0">
                        <div class="card-header">Last appointments</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th scope="col">Photo</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Visit time</th>
                                        <th scope="col">Number</th>
                                        <th scope="col">Doctor</th>
                                        <th scope="col">Injury / Condition</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td><img alt="" class="rounded-500" height="40"
                                                 src="<?= base_url() ?>assets/content/user-40-1.jpg"
                                                 width="40"></td>
                                        <td><strong>Liam</strong></td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-email p-0 mr-2"></span> liam@gmail.com
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">10 Feb 2018</div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">9:15 - 9:45</div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-cell-phone p-0 mr-2"></span> 0126595743
                                            </div>
                                        </td>
                                        <td>Dr. Benjamin</td>
                                        <td>mumps</td>
                                        <td>
                                            <div class="actions">
                                                <button class="btn btn-info btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-edit"></span></button>
                                                <button class="btn btn-error btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-delete"></span></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><img alt="" class="rounded-500" height="40"
                                                 src="<?= base_url() ?>assets/content/user-40-2.jpg"
                                                 width="40"></td>
                                        <td><strong>Emma</strong></td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-email p-0 mr-2"></span> emma@gmail.com
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">5 Dec 2018</div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">9:00 - 9:30</div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-cell-phone p-0 mr-2"></span> 0126595743
                                            </div>
                                        </td>
                                        <td>Dr. Liam</td>
                                        <td>arthritis</td>
                                        <td>
                                            <div class="actions">
                                                <button class="btn btn-info btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-edit"></span></button>
                                                <button class="btn btn-error btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-delete"></span></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><img alt="" class="rounded-500" height="40"
                                                 src="<?= base_url() ?>assets/content/user-40-3.jpg"
                                                 width="40"></td>
                                        <td><strong>Olivia</strong></td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-email p-0 mr-2"></span> olivia@gmail.com
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">13 Oct 2018</div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">12:00 - 12:45</div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-cell-phone p-0 mr-2"></span> 0126595743
                                            </div>
                                        </td>
                                        <td>Dr. Noah</td>
                                        <td>depression</td>
                                        <td>
                                            <div class="actions">
                                                <button class="btn btn-info btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-edit"></span></button>
                                                <button class="btn btn-error btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-delete"></span></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><img alt="" class="rounded-500" height="40"
                                                 src="<?= base_url() ?>assets/content/user-40-4.jpg"
                                                 width="40"></td>
                                        <td><strong>Ava</strong></td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-email p-0 mr-2"></span> ava@gmail.com
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">26 Dec 2018</div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">14:15 - 14:30</div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-cell-phone p-0 mr-2"></span> 0126595743
                                            </div>
                                        </td>
                                        <td>Dr. Emma</td>
                                        <td>diarrhoea</td>
                                        <td>
                                            <div class="actions">
                                                <button class="btn btn-info btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-edit"></span></button>
                                                <button class="btn btn-error btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-delete"></span></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><img alt="" class="rounded-500" height="40"
                                                 src="<?= base_url() ?>assets/content/user-40-5.jpg"
                                                 width="40"></td>
                                        <td><strong>Noah</strong></td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-email p-0 mr-2"></span> noah@gmail.co
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">15 Jun 2018</div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">17:30 - 18:00</div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-cell-phone p-0 mr-2"></span> 0126595743
                                            </div>
                                        </td>
                                        <td>Dr. James</td>
                                        <td>dyslexia</td>
                                        <td>
                                            <div class="actions">
                                                <button class="btn btn-info btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-edit"></span></button>
                                                <button class="btn btn-error btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-delete"></span></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><img alt="" class="rounded-500" height="40"
                                                 src="<?= base_url() ?>assets/content/user-40-6.jpg"
                                                 width="40"></td>
                                        <td><strong>Isabella</strong></td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-email p-0 mr-2"></span> isabella@gmail.com
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">2 Jul 2018</div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">10:00 - 10:15</div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-cell-phone p-0 mr-2"></span> 0126595743
                                            </div>
                                        </td>
                                        <td>Dr. Noah</td>
                                        <td>flu</td>
                                        <td>
                                            <div class="actions">
                                                <button class="btn btn-info btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-edit"></span></button>
                                                <button class="btn btn-error btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-delete"></span></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><img alt="" class="rounded-500" height="40"
                                                 src="<?= base_url() ?>assets/content/user-40-7.jpg"
                                                 width="40"></td>
                                        <td><strong>Sophia</strong></td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-email p-0 mr-2"></span> sophia@gmail.com
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">9 Oct 2018</div>
                                        </td>
                                        <td>
                                            <div class="text-muted text-nowrap">8:30 - 8:45</div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center nowrap text-primary"><span
                                                    class="icofont-ui-cell-phone p-0 mr-2"></span> 0126595743
                                            </div>
                                        </td>
                                        <td>Dr. Olivia</td>
                                        <td>fracture</td>
                                        <td>
                                            <div class="actions">
                                                <button class="btn btn-info btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-edit"></span></button>
                                                <button class="btn btn-error btn-sm btn-square rounded-pill"><span
                                                        class="btn-icon icofont-ui-delete"></span></button>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <div class="app-footer">
            <div class="footer-wrap">
                <div class="row h-100 align-items-center">
                    <div class="col-12 col-md-6 d-none d-md-block">
                        <ul class="page-breadcrumbs">
                            <li class="item"><a class="link" href="index.php#">Dashboards</a> <i
                                    class="separator icofont-thin-right"></i></li>
                            <li class="item"><a class="link" href="index.php#">Default</a> <i
                                    class="separator icofont-thin-right"></i></li>
                        </ul>
                    </div>
                    <div class="col-12 col-md-6 text-right">
                        <div class="d-flex align-items-center justify-content-center justify-content-md-end"><span>Version 1.0.0</span>
                            <button class="no-style ml-2 settings-btn" data-target="#settings" data-toggle="modal"><span
                                    class="icon icofont-ui-settings text-primary"></span></button>
                        </div>
                    </div>
                </div>
                <div class="footer-skeleton">
                    <div class="row align-items-center">
                        <div class="col-12 col-md-6 d-none d-md-block">
                            <ul class="page-breadcrumbs">
                                <li class="item bg-1 animated-bg"></li>
                                <li class="item bg animated-bg"></li>
                            </ul>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="info justify-content-center justify-content-md-end">
                                <div class="version bg animated-bg"></div>
                                <div class="settings animated-bg"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-overlay"></div>
    </div>
</div><!-- Add patients modals -->
<div aria-hidden="true" class="modal fade" id="add-patient" role="dialog" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Add new patient</h5></div>
            <div class="modal-body">
                <form>
                    <div class="form-group avatar-box d-flex"><img alt="" class="rounded-500 mr-4"
                                                                   height="40" src="<?= base_url() ?>assets/content/anonymous-400.jpg"
                                                                   width="40">
                        <button class="btn btn-outline-primary" type="button">Select image<span
                                class="btn-icon icofont-ui-user ml-2"></span></button>
                    </div>
                    <div class="form-group"><input class="form-control" placeholder="Name" type="text"></div>
                    <div class="form-group"><input class="form-control" placeholder="Number" type="number"></div>
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group"><input class="form-control" placeholder="Age" type="number"></div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group"><select class="selectpicker" title="Gender">
                                <option class="d-none">Gender</option>
                                <option>Male</option>
                                <option>Female</option>
                            </select></div>
                        </div>
                    </div>
                    <div class="form-group mb-0"><textarea class="form-control" placeholder="Address"
                                                           rows="3"></textarea></div>
                </form>
            </div>
            <div class="modal-footer d-block">
                <div class="actions justify-content-between">
                    <button class="btn btn-error" data-dismiss="modal" type="button">Cancel</button>
                    <button class="btn btn-info" type="button">Add patient</button>
                </div>
            </div>
        </div>
    </div>
</div><!-- end Add patients modals --><!-- Add patients modals -->
<div aria-hidden="true" class="modal fade" id="settings" role="dialog" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Application's settings</h5></div>
            <div class="modal-body">
                <form>
                    <div class="form-group"><label>Layout</label> <select class="selectpicker" id="layout"
                                                                          title="Layout">
                        <option value="horizontal-layout">Horizontal</option>
                        <option value="vertical-layout">Vertical</option>
                    </select></div>
                    <div class="form-group"><label>Light/dark topbar</label>
                        <div class="custom-control custom-switch"><input class="custom-control-input" id="topbar"
                                                                         type="checkbox"> <label
                                class="custom-control-label" for="topbar"></label></div>
                    </div>
                    <div class="form-group"><label>Light/dark sidebar</label>
                        <div class="custom-control custom-switch"><input class="custom-control-input" id="sidebar"
                                                                         type="checkbox"> <label
                                class="custom-control-label" for="sidebar"></label></div>
                    </div>
                    <div class="form-group mb-0"><label>Boxed/fullwidth mode</label>
                        <div class="custom-control custom-switch"><input checked="checked" class="custom-control-input"
                                                                         id="boxed" type="checkbox"> <label
                                class="custom-control-label" for="boxed"></label></div>
                    </div>
                </form>
            </div>
            <div class="modal-footer d-block">
                <div class="actions justify-content-between">
                    <button class="btn btn-secondary" data-dismiss="modal" type="button">Cancel</button>
                    <button class="btn btn-error" id="reset-to-default" type="button">Reset to default</button>
                </div>
            </div>
        </div>
    </div>
</div><!-- end Add patients modals -->
<script src="<?= base_url() ?>assets/js/jquery-3.3.1.min.js"></script>
<!--<script src="<?= base_url() ?>assets/js/jquery-migrate-1.4.1.min.js"></script>-->
<script src="<?= base_url() ?>assets/js/popper.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.typeahead.min.js"></script>
<script src="<?= base_url() ?>assets/js/datatables.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap-select.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.barrating.min.js"></script>
<script src="<?= base_url() ?>assets/js/Chart.min.js"></script>
<script src="<?= base_url() ?>assets/js/raphael-min.js"></script>
<script src="<?= base_url() ?>assets/js/morris.min.js"></script>
<script src="<?= base_url() ?>assets/js/echarts.min.js"></script>
<script src="<?= base_url() ?>assets/js/echarts-gl.min.js"></script>
<script src="<?= base_url() ?>assets/js/main.js"></script>
</body>
</html>
