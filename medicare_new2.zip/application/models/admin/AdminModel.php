<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class adminModel extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function adminLogin($user_data){
		$this->db->where($user_data);
		$query = $this->db->get('admin');
		if ($query->num_rows() > 0)
		{
			foreach ($query->result() as $row)
			{
				$user_data = array(
					'aId' => $row->aId,
					'username' => $row->username,
				);
			}
			return $user_data;
		} else {
			return 0;
		}
	}


}

/* End of file adminModel.php */
