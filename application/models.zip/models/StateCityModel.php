<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class stateCityModel extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function fetchState(){
		$query = $this->db->get('state');
		foreach ($query->result() as $row)
		{
			$state[] = array(
				'stateId' => $row->stateId,
				'stateName' => $row->stateName
			);
		}
		return $state;
	}

	public function fetchCity($id){
		$this->db->where('stateId', $id);
		$query = $this->db->get('city');

		foreach ($query->result() as $row)
		{
			$state[] = array(
				'cityId' => $row->cityId,
				'cityName' => $row->cityName
			);
		}

		return $state;
	}

	public function fetchStateCity($cityId){
		$row = $this->db->where('cityId', $cityId)
					->join('state','state.stateId=city.stateId')
					->get('city')->row();

		$res = array(
			'cityName' => $row->cityName,
			'stateName' => $row->stateName,
		);

		return $res;
	}

}

/* End of file stateCityModel.php */
