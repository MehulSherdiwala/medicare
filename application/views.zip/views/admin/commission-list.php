<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>MediCare</title>
	<meta content="MedicApp" name="keywords">
	<meta content="" name="description">
	<meta content="" name="author">
	<meta content="width=device-width,initial-scale=1" name="viewport"><!-- Favicon -->
	<link type="image/x-icon" href="<?= base_url() ?>assets/img/fav.png" rel="icon"><!-- Plugins CSS -->
	<link href="<?= base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/icofont.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/datatables.min.css" rel="stylesheet">
	<link href="<?= base_url() ?>assets/css/bootstrap-select.min.css" rel="stylesheet">
	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/fontawesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/fontawesome/css/all.min.css">
	<link href="<?= base_url() ?>assets/css/styleMedic.css?version=5" rel="stylesheet">
</head>
<body class="vertical-layout boxed">
<div class="app-loader main-loader">
	<div class="loader-box">
		<div class="bounceball"></div>
		<img src="<?= base_url() ?>assets/img/MediCareLogo.png" alt="logo">
	</div>
</div><!-- .main-loader -->
<div class="page-box">
	<div class="app-container"><!-- Horizontal navbar -->

		<?php
		include "sidebar.php"
		?>

		<main class="main-content">
			<div class="app-loader"><i class="icofont-spinner-alt-4 rotate"></i></div>
			<div class="main-content-wrap">
				<header class="page-header"><h1 class="page-title">Commission</h1></header>
				<div class="page-content">
					<div class="card mb-0">
						<div class="card-body">
							<div class="table-responsive">

								<table class="table" id="data-table">
									<thead>
										<tr>
											<th width="15%">Commission Transaction Id</th>
											<th>User Type</th>
											<th>User Name</th>
											<th>Total</th>
											<th></th>
										</tr>
									</thead>
									<tbody>
										<?php
										foreach ($list as $item)
										{
											?>
											<tr>
												<td><?= $item['ctId']?></td>
												<td><?= $item['userType']?></td>
												<td><?= $item['username']?></td>
												<td><?= $item['total']?></td>
												<td><button class="btn btn-info btn-sm btn-square rounded-pill view-commission" data-crid="<?= $item['ctId'] ?>" data-target="#view-commission" data-toggle="modal">
														<span class="btn-icon icofont-eye-alt"></span></button></td>
											</tr>
											<?php
										}
										?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="app-footer">
			<div class="footer-wrap">
				<div class="row h-100 align-items-center">
					<div class="col-12 col-md-6 d-none d-md-block">
						<ul class="page-breadcrumbs">
							<li class="item"><a class="link" href="javascript:void(0)">Home</a> <i
									class="separator icofont-thin-right"></i></li>
							<li class="item"><a class="link" href="javascript:void(0)">Commission</a> <i
									class="separator icofont-thin-right"></i></li>
						</ul>
					</div>
				</div>
				<div class="footer-skeleton">
					<div class="row align-items-center">
						<div class="col-12 col-md-6 d-none d-md-block">
							<ul class="page-breadcrumbs">
								<li class="item bg-1 animated-bg"></li>
								<li class="item bg animated-bg"></li>
							</ul>
						</div>
						<div class="col-12 col-md-6">
							<div class="info justify-content-center justify-content-md-end">
								<div class="version bg animated-bg"></div>
								<div class="settings animated-bg"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="content-overlay"></div>
	</div>
	<div aria-hidden="true" class="modal fade" id="view-commission" role="dialog" tabindex="-1">
		<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
			<div class="modal-content">
				<div class="modal-header"><h5 class="modal-title">Commission List</h5></div>
				<div class="modal-body">
					<h6 class="m-0">User Type &nbsp;&nbsp;&nbsp;: <span id="userType"></span></h6>
					<h6 class="mt-0">User Name &nbsp;: <span id="username"></span></h6>

					<div id="data"></div>
				</div>
				<div class="modal-footer d-block">
					<div class="actions justify-content-between">
						<button class="btn btn-error" data-dismiss="modal" type="button">Cancel</button>
					</div>
				</div>
			</div>
		</div>
	</div><!-- end Add appointment modals -->
	<script src="<?= base_url() ?>assets/js/jquery-3.3.1.min.js"></script>
	<script src="<?= base_url() ?>assets/js/popper.min.js"></script>
	<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
	<script src="<?= base_url() ?>assets/js/datatables.min.js"></script>
	<script src="<?= base_url() ?>assets/js/bootstrap-select.min.js"></script>
	<!-- parsley JS -->
	<script src="<?= base_url() ?>assets/plugins/parsley/js/parsley.min.js"></script>
	<script src="<?= base_url() ?>assets/js/main.js"></script>

	<script>
		$("#data-table").DataTable();

		$(".view-commission").on('click', function () {
			const ctId	=	$(this).data('crid');
			fetchCommission(ctId);
		});
		// fetchCommission();
		async function fetchCommission(ctId) {
			const response = await fetch('<?= base_url()?>admin/Commission/commissionList/' + ctId);
			const myJson = await response.json();
			$("#userType").text(myJson.type);
			$("#username").text(myJson.username);
			let html = '';
			html += '<table class="table data-table">\n' +
				'<thead>\n' +
				'<tr>\n' +
				'<th scope="col" width="30%">Commission Transaction Id</th>\n' +
				'<th scope="col">Amount</th>\n' +
				'<th scope="col">Date</th>\n' +
				'</tr>\n' +
				'</thead>\n' +
				'<tbody>';
			for (let i = 0; i < myJson['list'].length; i++) {

				html += '<tr>\n' +
					'<td>'+ myJson['list'][i].ctId+'</td>\n' +
					'<td>'+ myJson['list'][i].amount+'</td>\n' +
					'<td>'+ myJson['list'][i].datetime+'</td>\n' +
					'</tr>';
			}
			html += '</tbody></table>';
			$("#data").html(html);
			console.log(html);
			// $(".data-table").DataTable();
		}

	</script>
</body>
</html>
