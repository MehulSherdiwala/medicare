
<div class="app-navbar horizontal" id="navbar1">
	<div class="navbar-wrap">
		<button class="no-style navbar-toggle navbar-open d-lg-none"><span></span><span></span><span></span>
		</button>
		<form class="app-search d-none d-md-block">
			<div class="form-group typeahead__container with-suffix-icon mb-0">
				<div class="typeahead__field">
					<div class="typeahead__query"><input autocomplete="off"
														 class="form-control autocomplete-control topbar-search"
														 data-source="<?= base_url() ?>assets/data/search-menu.json"
														 placeholder="Type page's title"
														 type="search">
						<div class="suffix-icon icofont-search"></div>
					</div>
				</div>
			</div>
		</form>
		<div class="app-actions">
			<div class="dropdown item">
				<button aria-expanded="false" aria-haspopup="true" class="no-style dropdown-toggle"
						data-offset="0, 12" data-toggle="dropdown" type="button"><span
						class="icon icofont-notification"></span> <span
						class="badge badge-danger badge-sm">5</span></button>
				<div class="dropdown-menu dropdown-menu-right dropdown-menu-w-280">
					<div class="menu-header"><h4 class="h5 menu-title mt-0 mb-0">Notifications</h4><a
							class="text-danger" href="#">Clear All</a></div>
					<ul class="list">
						<li><a href="#"><span class="icon icofont-heart"></span>
								<div class="content"><span class="desc">Sara Crouch liked your photo</span> <span
										class="date">17 minutes ago</span></div>
							</a></li>
						<li><a href="#"><span class="icon icofont-users-alt-6"></span>
								<div class="content"><span class="desc">New user registered</span> <span
										class="date">23 minutes ago</span></div>
							</a></li>
						<li><a href="#"><span class="icon icofont-share"></span>
								<div class="content"><span class="desc">Amanda Lie shared your post</span> <span
										class="date">25 minutes ago</span></div>
							</a></li>
						<li><a href="#"><span class="icon icofont-users-alt-6"></span>
								<div class="content"><span class="desc">New user registered</span> <span
										class="date">32 minutes ago</span></div>
							</a></li>
						<li><a href="#"><span class="icon icofont-ui-message"></span>
								<div class="content"><span class="desc">You have a new message</span> <span
										class="date">58 minutes ago</span></div>
							</a></li>
					</ul>
					<div class="menu-footer">
						<button class="btn btn-primary btn-block">View all notifications <span
								class="btn-icon ml-2 icofont-tasks-alt"></span></button>
					</div>
				</div>
			</div>
			<div class="dropdown item">
				<button aria-expanded="false" aria-haspopup="true" class="no-style dropdown-toggle"
						data-offset="0, 10" data-toggle="dropdown" type="button"><span
						class="d-flex align-items-center"><img alt="" class="rounded-500 mr-1"
															   height="40"
															   src="<?= base_url() ?>assets/content/user-400-1.jpg"
															   width="40"> <i
							class="icofont-simple-down"></i></span></button>
				<div class="dropdown-menu dropdown-menu-right dropdown-menu-w-180">
					<ul class="list">
						<li><a class="align-items-center" href="#"><span
									class="icon icofont-ui-home"></span> Edit account</a></li>
						<li><a class="align-items-center" href="#"><span
									class="icon icofont-ui-user"></span> User profile</a></li>
						<li><a class="align-items-center" href="#"><span
									class="icon icofont-ui-calendar"></span> Calendar</a></li>
						<li><a class="align-items-center" href="#"><span
									class="icon icofont-ui-settings"></span> Settings</a></li>
						<li><a class="align-items-center" href="<?= base_url() ?>admin/Login/Logout">
								<span class="icon icofont-logout"></span> Log Out</a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="navbar-skeleton horizontal">
			<div class="left-part d-flex align-items-center"><span
					class="navbar-button bg animated-bg d-lg-none"></span> <span
					class="sk-logo bg animated-bg d-none d-lg-block"></span> <span
					class="search d-none d-md-block bg animated-bg"></span></div>
			<div class="right-part d-flex align-items-center">
				<div class="icon-box"><span class="icon bg animated-bg"></span> <span class="badge"></span>
				</div>
				<span class="avatar bg animated-bg"></span></div>
		</div>
	</div>
</div>
<div class="app-navbar vertical" id="navbar2">
	<div class="navbar-wrap">
		<button class="no-style navbar-toggle navbar-close icofont-close-line d-lg-none"></button>
		<div class="app-logo">
			<div class="logo-wrap"><img alt="" class="logo-img" height="33" src="<?= base_url() ?>assets/img/MediCareLogo.png"
										width="147"></div>
		</div>
		<div class="main-menu">
			<nav class="main-menu-wrap">
				<ul class="menu-ul">
					<li class="menu-item"><span class="group-title">Medicine</span></li>
					<li class="menu-item"><a class="item-link" href=""><span
								class="link-icon icofont-thermometer-alt"></span> <span
								class="link-text">Dashboard</span></a></li>
					<li class="menu-item"><a class="item-link" href="appointments.html"><span
								class="link-icon icofont-stethoscope-alt"></span> <span class="link-text">Appointments</span></a>
					</li>
					<li class="menu-item"><a class="item-link" href="doctors.html"><span
								class="link-icon icofont-doctor"></span> <span class="link-text">Doctors</span></a>
					</li>
					<li class="menu-item"><a class="item-link" href="departments.html"><span
								class="link-icon icofont-nurse"></span> <span
								class="link-text">Departments</span></a></li>
					<li class="menu-item"><a class="item-link" href="patients.html"><span
								class="link-icon icofont-paralysis-disability"></span> <span class="link-text">Patients</span></a>
					</li>
					<li class="menu-item"><a class="item-link" href="payments.html"><span
								class="link-icon icofont-pay"></span> <span class="link-text">Payments</span></a>
					</li>
					<li class="menu-item"><span class="group-title">UI Kit</span></li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Components</span> <span
								class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="alerts.html"><span
										class="link-text">Alerts</span></a></li>
							<li class="menu-item"><a class="item-link" href="autocompletes.html"><span
										class="link-text">Autocompletes</span></a></li>
							<li class="menu-item"><a class="item-link" href="badges.html"><span
										class="link-text">Badges</span></a></li>
							<li class="menu-item"><a class="item-link" href="buttons.html"><span
										class="link-text">Buttons</span></a></li>
							<li class="menu-item"><a class="item-link" href="cards.html"><span
										class="link-text">Cards</span></a></li>
							<li class="menu-item"><a class="item-link" href="checkboxes.html"><span
										class="link-text">Checkboxes</span></a></li>
							<li class="menu-item"><a class="item-link" href="contacts.html"><span
										class="link-text">Contacts</span></a></li>
							<li class="menu-item"><a class="item-link" href="inputs.html"><span
										class="link-text">Inputs</span></a></li>
							<li class="menu-item"><a class="item-link" href="modal-windows.html"><span
										class="link-text">Modal windows</span></a></li>
							<li class="menu-item"><a class="item-link" href="radio-buttons.html"><span
										class="link-text">Radio buttons</span></a></li>
							<li class="menu-item"><a class="item-link" href="ratings.html"><span
										class="link-text">Ratings</span></a></li>
							<li class="menu-item"><a class="item-link" href="selects.html"><span
										class="link-text">Selects</span></a></li>
							<li class="menu-item"><a class="item-link" href="switchers.html"><span
										class="link-text">Switchers</span></a></li>
							<li class="menu-item"><a class="item-link" href="textareas.html"><span
										class="link-text">Textareas</span></a></li>
							<li class="menu-item"><a class="item-link" href="v-timelines.html"><span
										class="link-text">Vertical timeline</span></a></li>
						</ul>
					</li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Icons</span> <span
								class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="icons-sli.html"><span
										class="link-text">Simple line icons</span></a></li>
							<li class="menu-item"><a class="item-link" href="icons-if.html"><span
										class="link-text">Icofont icons</span></a></li>
						</ul>
					</li>
					<li class="menu-item"><a class="item-link" href="typography.html"><span class="link-text">Typography</span></a>
					</li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Tables</span> <span class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="bootstrap-tables.html"><span
										class="link-text">Bootstrap tables</span></a></li>
							<li class="menu-item"><a class="item-link" href="data-tables.html"><span
										class="link-text">Data tables</span></a></li>
						</ul>
					</li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Forms</span> <span
								class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="form-elements.html"><span
										class="link-text">Elements</span></a></li>
							<li class="menu-item"><a class="item-link" href="form-layout.html"><span
										class="link-text">Layout</span></a></li>
							<li class="menu-item"><a class="item-link" href="form-validation.html"><span
										class="link-text">Validation</span></a></li>
						</ul>
					</li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Charts</span> <span class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="charts-chart-js.html"><span
										class="link-text">Chart.js</span></a></li>
							<li class="menu-item"><a class="item-link" href="charts-morris-js.html"><span
										class="link-text">Morris.js</span></a></li>
							<li class="menu-item"><a class="item-link" href="charts-echarts.html"><span
										class="link-text">Echarts</span></a></li>
						</ul>
					</li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Maps</span> <span
								class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="google-map.html"><span
										class="link-text">Google map</span></a></li>
							<li class="menu-item"><a class="item-link" href="leaflet-map.html"><span
										class="link-text">Leaflet map</span></a></li>
							<li class="menu-item"><a class="item-link" href="echarts-map.html"><span
										class="link-text">Echarts map</span></a></li>
						</ul>
					</li>
					<li class="menu-item"><span class="group-title">Apps</span></li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Service pages</span> <span
								class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="invoices.html"><span
										class="link-text">Invoices</span></a></li>
							<li class="menu-item"><a class="item-link" href="pricing.html"><span
										class="link-text">Pricing</span></a></li>
							<li class="menu-item"><a class="item-link" href="edit-account.html"><span
										class="link-text">Edit account</span></a></li>
							<li class="menu-item"><a class="item-link" href="user-profile.html"><span
										class="link-text">User profile</span></a></li>
							<li class="menu-item"><a class="item-link" href="events-timeline.html"><span
										class="link-text">Events timeline</span></a></li>
						</ul>
					</li>
					<li class="menu-item has-sub"><a class="item-link" href="#"><span
								class="link-text">Sessions</span> <span
								class="link-caret icofont-thin-right"></span></a>
						<ul class="sub">
							<li class="menu-item"><a class="item-link" href="sign-in.html"><span
										class="link-text">Sign in</span></a></li>
							<li class="menu-item"><a class="item-link" href="sign-up.html"><span
										class="link-text">Sign up</span></a></li>
							<li class="menu-item"><a class="item-link" href="page-404.html"><span
										class="link-text">404</span></a></li>
							<li class="menu-item"><a class="item-link" href="page-500.html"><span
										class="link-text">500</span></a></li>
						</ul>
					</li>
				</ul>
			</nav>
		</div>
		<div class="add-patient">
			<button class="btn btn-primary" data-target="#add-patient" data-toggle="modal"><span
					class="btn-icon icofont-plus mr-2"></span> Add Patient
			</button>
		</div>
		<div class="assistant-menu"><a class="link" href="#"><span
					class="link-icon icofont-ui-settings"></span>Settings </a><a class="link"
																				 href="#"><span
					class="link-icon icofont-question-square"></span>FAQ &amp; Support</a></div>
		<div class="navbar-skeleton vertical">
			<div class="top-part">
				<div class="sk-logo bg animated-bg"></div>
				<div class="sk-menu"><span class="sk-menu-item menu-header bg-1 animated-bg"></span> <span
						class="sk-menu-item bg animated-bg w-75"></span> <span
						class="sk-menu-item bg animated-bg w-80"></span> <span
						class="sk-menu-item bg animated-bg w-50"></span> <span
						class="sk-menu-item bg animated-bg w-75"></span> <span
						class="sk-menu-item bg animated-bg w-50"></span> <span
						class="sk-menu-item bg animated-bg w-60"></span></div>
				<div class="sk-menu"><span class="sk-menu-item menu-header bg-1 animated-bg"></span> <span
						class="sk-menu-item bg animated-bg w-60"></span> <span
						class="sk-menu-item bg animated-bg w-40"></span> <span
						class="sk-menu-item bg animated-bg w-60"></span> <span
						class="sk-menu-item bg animated-bg w-40"></span> <span
						class="sk-menu-item bg animated-bg w-40"></span> <span
						class="sk-menu-item bg animated-bg w-40"></span> <span
						class="sk-menu-item bg animated-bg w-40"></span></div>
				<div class="sk-menu"><span class="sk-menu-item menu-header bg-1 animated-bg"></span> <span
						class="sk-menu-item bg animated-bg w-60"></span> <span
						class="sk-menu-item bg animated-bg w-50"></span></div>
				<div class="sk-button animated-bg w-90"></div>
			</div>
			<div class="bottom-part">
				<div class="sk-menu"><span class="sk-menu-item bg-1 animated-bg w-60"></span> <span
						class="sk-menu-item bg-1 animated-bg w-80"></span></div>
			</div>
			<div class="horizontal-menu"><span class="sk-menu-item bg animated-bg"></span> <span
					class="sk-menu-item bg animated-bg"></span> <span
					class="sk-menu-item bg animated-bg"></span> <span
					class="sk-menu-item bg animated-bg"></span> <span
					class="sk-menu-item bg animated-bg"></span> <span
					class="sk-menu-item bg animated-bg"></span></div>
		</div>
	</div>
</div>
