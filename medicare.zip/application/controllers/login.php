<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$uId = $this->session->userdata('uId');
		if (isset($uId)){
			redirect('index');
		}
		$this->load->view('login');
	}

	private function encrypt_decrypt($action, $string)
	{
		$output = false;
		$encrypt_method = "AES-256-CBC";
		$secret_key = 'This is my secret key';
		$secret_iv = 'This is my secret iv';
		// hash
		$key = hash('sha256', $secret_key);
		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
		$iv = substr(hash('sha256', $secret_iv), 0, 16);
		if( $action == 'encrypt' ) {
			$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
			$output = base64_encode($output);
		}
		else if( $action == 'decrypt' ){
			$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
		}
		return $output;
	}

	public function LoginVerify(){
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('pwd', 'Password', 'trim|required|min_length[6]',
			array(
				'min_length'     => '%s Contains at least 6 characters.'
			)
		);

		if ($this->form_validation->run() == TRUE or FALSE)
		{
			$user_data = array(
				'email' => $this->input->post('email'),
				'pwd' => $this->encrypt_decrypt( 'encrypt',$this->input->post('pwd')),
			);
			$this->load->model('loginModel','login');
			$result = $this->login->userLogin($user_data);
			print_r($result);
			if ($result == 0){
				$data['error'] ='Invalid Email Or Password';
				$this->load->view('login',$data);
			} else{
				$array = array(
					'uId' => $result['uId'],
					'userType' => $result['userType'],
					'username' => $result['username'],
					'profile' => $result['emptyRow']
				);

				$this->session->set_userdata($array);
				redirect('index');

			}
		} else
		{
			$this->load->view('login');
		}

	}


	public function Logout(){
		$this->session->sess_destroy();
		redirect('index');
	}

	public function doctorPharmacist(){
	}

}

/* End of file Login.php */
