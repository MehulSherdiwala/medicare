<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class patientProfileSetting extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$uId = $this->session->userdata('uId');
		if (!isset($uId)){
			redirect('index');
		}
		$this->load->model('stateCityModel');
		$data['state'] = $this->stateCityModel->fetchState();
		$id = $this->session->userdata('uId');
		$this->load->model('patient');
		$data['patientDetail'] = $this->patient->getDetail($id);
		$this->load->view('patient-profile-settings',$data);
	}

	public function updateData(){
		$oldEmail = $this->input->post('oldEmail');
		$email = $this->input->post('email');

		if ($oldEmail != $email){
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[patient.email]',
				array('is_unique' => 'This %s already exists.')
			);
			if ($this->form_validation->run() == TRUE or FALSE)
			{
				redirect('patient-profile-setting');
			}
		}

		$user_data = array(
			'username' => $this->input->post('username'),
			'email' => $this->input->post('email'),
			'phone' => $this->input->post('phone'),
			'gender' => $this->input->post('gender'),
			'dob' => date('Y-m-d H:i:s', strtotime($this->input->post('dob'))),
			'description' => $this->input->post('description'),
			'address' => $this->input->post('address'),
			'cityId' => $this->input->post('city'),
			'pincode' => $this->input->post('pincode'),
			'updatedAt' => date('Y-m-d H:i:s', now('Asia/Kolkata')),
		);
		$this->load->model('patient');
		$id = $this->session->userdata('uId');
		$result = $this->patient->updateProfile($id,$user_data);
		if ($result == 1){
			$array = array(
				'profile' => 0
			);
			$this->session->set_userdata($array);
		}
		redirect('patient-profile-setting');
	}
}

/* End of file patientProfileSetting.php */
