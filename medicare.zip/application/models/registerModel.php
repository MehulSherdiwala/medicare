<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class registerModel extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function addPatient($userdata){
		$this->db->insert('patient', $userdata);
		return $this->db->insert_id();
	}
	public function addDoctor($userdata){
		$this->db->insert('doctor', $userdata);
		return $this->db->insert_id();
	}
	public function addPharmacist($userdata){
		$this->db->insert('pharmacist', $userdata);
		return $this->db->insert_id();
	}

}

/* End of file registerModel.php */
