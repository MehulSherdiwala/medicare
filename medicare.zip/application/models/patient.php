<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class patient extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function getDetail($id){
		$this->db->where('pId', $id);
		$query = $this->db->get('patient');
		$row = $query->row();
		if($row->cityId != 0){
			$this->db->where('cityId', $row->cityId);
			$queryCity = $this->db->get('city');
			$rowCity = $queryCity->row();
		}

		return array(
			"pId" => $row->pId,
			"username" => $row->username,
			"email" => $row->email,
			"phone" => $row->phone,
			"gender" => $row->gender,
			"dob" => date('d-m-Y', strtotime($row->dob)),
			"description" => $row->description,
			"address" => $row->address,
			"pincode" => $row->pincode,
			"cityId" => $row->cityId,
			"stateId" => (isset($rowCity))? $rowCity->stateId : 0,
		);
	}

	public function updateProfile($id,$data){

		$this->db->where('pId', $id);
		$val = $this->db->update('patient', $data);
		return $val;
	}

}

/* End of file patient.php */
