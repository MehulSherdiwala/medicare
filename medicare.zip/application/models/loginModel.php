<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class loginModel extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}


	public function userLogin($user_data){
		$this->db->where($user_data);
		if ($this->db->get('patient')->num_rows() > 0)
		{
			$this->db->where($user_data);
			$query = $this->db->get('patient');

			$row = $query->row();
			$user_data = array(
				'uId' => $row->pId,
				'userType' => '3',
				'username' => $row->username,
				'emptyRow' => 0,
			);

			$emptyRow = $this->db->query("
				SELECT SUM(CASE
				   WHEN address is null or COALESCE(TRIM(address), '') = '' THEN 1
				   WHEN description is null or COALESCE(TRIM(description), '') = '' THEN 1
				   ELSE 0 END
			   	) as empty_fields FROM patient WHERE pId = $row->pId;");

			$user_data['emptyRow'] = $emptyRow->row()->empty_fields;

			return $user_data;
		} elseif ($this->db->get('doctor')->num_rows() > 0) {
			$this->db->where($user_data);
			$query = $this->db->get('doctor');
			foreach ($query->result() as $row)
			{
				$user_data = array(
					'uId' => $row->dId,
					'userType' => '1',
					'username' => $row->username,
				);
			}
			return $user_data;
		} elseif ($this->db->get('pharmacist')->num_rows() > 0){

			$this->db->where($user_data);
			$query = $this->db->get('pharmacist');
			foreach ($query->result() as $row)
			{
				$user_data = array(
					'uId' => $row->pharId,
					'userType' => '2',
					'username' => $row->username,
				);
			}
			return $user_data;
		} else {
			return 0;
		}
	}

}

/* End of file loginModel.php */
